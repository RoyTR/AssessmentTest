class CBomba
{
private:
	int x;
	int y;
	int diametroBomb;
	int intervalo_explosion;
	int Indice;
	int Indice_explosion;
	int alcance;
public:
	CBomba(int x,int y,int diametroBomb,int alcance);
	~CBomba();
	void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2);
	int Get_intervalo_explosion();
	int Get_x();
	int Get_y();
	int Get_diametroBomb();
};

class CBombas
{
private:
	int n;
	int aux;
	int alcance;
	CBomba **V;
	int h;
public:
	CBombas();
	~CBombas();
	void Poner1Bomba(int x,int y);
	void Borrar1Bomba();
	void MostrarBombas(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2);
	bool ValidarMuertePorExplosion(int x,int y,int anchoB,int altoB);
	bool SobreBomba(int posx,int posy,int posx2,int posy2,int an,int al);
	int Get_n();
	void Set_n(int n);
	int Get_ALCANCE();
	void Set_ALCANCE(int alcance);
};