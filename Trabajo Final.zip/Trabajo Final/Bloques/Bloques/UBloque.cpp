#include "stdafx.h"

CEspacio::CEspacio(int x,int y,int size,int tipo)
{
	this->x=x;
	this->y=y;
	this->size=size;
	this->tipo=tipo;
}
CEspacio::~CEspacio()
{
}
void CEspacio::Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2,System::Drawing::Bitmap ^bmp3,System::Drawing::Bitmap ^bmp4,System::Drawing::Bitmap ^bmp5,System::Drawing::Bitmap ^bmp6)
{
	if(tipo==1)
		C->DrawImage(bmp,x,y,size,size);
	if(tipo==2)
		C->DrawImage(bmp2,x,y,size,size);
	if(tipo==3)
		C->DrawImage(bmp3,x,y,size,size);
	if(tipo==4)
		C->DrawImage(bmp4,x,y,size,size);
	if(tipo==5)
		C->DrawImage(bmp5,x,y,size,size);
	if(tipo==6)
		C->DrawImage(bmp6,x,y,size,size);
}
void CEspacio::Set_tipo(int tipo)
{
	this->tipo=tipo;
}
int CEspacio::Get_x()
{
	return x;
}
int CEspacio::Get_y()
{
	return y;
}
int CEspacio::Get_size()
{
	return size;
}
int CEspacio::Get_tipo()
{
	return tipo;
}

CNormal::CNormal(int x,int y,int size,int tipo):CEspacio(x,y,size,tipo)
{
}
CNormal::~CNormal()
{
}

CObstaculo::CObstaculo(int x,int y,int size,int tipo):CEspacio(x,y,size,tipo)
{
}
CObstaculo::~CObstaculo()
{
}

CMuro::CMuro(int x,int y,int size,int tipo):CEspacio(x,y,size,tipo)
{
}
CMuro::~CMuro()
{
}

CPoder1::CPoder1(int x,int y,int size,int tipo):CEspacio(x,y,size,tipo)
{
}
CPoder1::~CPoder1()
{
}

CPoder2::CPoder2(int x,int y,int size,int tipo):CEspacio(x,y,size,tipo)
{
}
CPoder2::~CPoder2()
{
}

CPuerta::CPuerta(int x,int y,int size,int tipo):CEspacio(x,y,size,tipo)
{
}
CPuerta::~CPuerta()
{
}

//////////

CVecEspacios::CVecEspacios(int nivel)
{
	V=new CEspacio*[169];
	int x=10-50,y=10;
	int size=50;

	if(nivel==1)
	{
		for(int i=0;i<169;i++)
		{
			if(i%13==0 && i!=0)
			{
				x=10;
				y+=50;
			}
			else
				x+=50;

			
			switch(i)
			{
			case 14:case 15:case 17:case 18:case 20:case 21:case 23:case 24:
			case 40:case 41:case 43:case 44:case 46:case 47:case 49:case 50:
			case 66:case 67:case 69:case 70:case 72:case 73:case 75:case 76:
			case 92:case 93:case 95:case 96:case 98:case 99:case 101:case 102:
			case 118:case 119:case 121:case 122:case 124:case 125:case 127:case 128:
			case 144:case 145:case 147:case 148:case 150:case 151:case 153:case 154:
				V[i]=new CMuro(x,y,size,3);
				break;
			case 19:case 22:
			case 42:case 45:case 48:
			case 68:case 71:case 74:
			case 94:case 97:case 100:
			case 120:case 123:case 126:
			case 146:case 149:case 152:
				V[i]=new CObstaculo(x,y,size,2);
				break;
			default:
				V[i]=new CNormal(x,y,size,1);
				break;
			}
		}
	}

	if(nivel==2)
	{
		for(int i=0;i<169;i++)
		{
			if(i%13==0 && i!=0)
			{
				x=10;
				y+=50;
			}
			else
				x+=50;

			switch(i)
			{
			case 14:case 16:case 18:case 20:case 24:
			case 40:case 42:case 44:case 46:case 48:case 50:
			case 66:case 68:case 70:case 72:case 74:case 76:
			case 92:case 94:case 96:case 98:case 100:case 102:
			case 118:case 120:case 122:case 124:case 126:case 128:
			case 144:case 146:case 148:case 150:case 152:case 154:
				V[i]=new CMuro(x,y,size,3);
				break;

			case 15:case 17:case 21:case 22:
			case 43:case 45:case 47:
			case 67:case 69:case 71:case 73:case 75:
			case 95:case 97:case 99:
			case 119:case 121:case 125:case 127:
			case 145:case 147:case 149:case 151:case 153:			
				V[i]=new CObstaculo(x,y,size,2);
				break;
			default:
				V[i]=new CNormal(x,y,size,1);
				break;
			}
		}
	}
}
CVecEspacios::~CVecEspacios()
{
	for(int i=0;i<169;i++)
		delete V[i];
	delete []V;
}
void CVecEspacios::Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2,System::Drawing::Bitmap ^bmp3,System::Drawing::Bitmap ^bmp4,System::Drawing::Bitmap ^bmp5,System::Drawing::Bitmap ^bmp6)
{
	for(int i=0;i<169;i++)
		V[i]->Mostrar(C,bmp,bmp2,bmp3,bmp4,bmp5,bmp6);
}
bool CVecEspacios::DestruccionDeBloqueBoom(System::Random ^R,CBombas *P)
{
	for(int i=0;i<169;i++)
	{
		if(V[i]->Get_tipo()==2)
			if(P->ValidarMuertePorExplosion(V[i]->Get_x(),V[i]->Get_y(),V[i]->Get_size(),V[i]->Get_size()))
			{
				if(i==22)
					V[i]->Set_tipo(6);
				else
				{
					int poder=R->Next(0,10);
					if(poder==4)
						V[i]->Set_tipo(4);
					else
						if(poder==5)
							V[i]->Set_tipo(5);
						else
							V[i]->Set_tipo(1);
				}
				return true;
			}
	}
	return false;

}
bool CVecEspacios::ValidarMovimiento(int posx,int posy,int posx2,int posy2)
{
	bool validado=false;
	bool validado2=false;
	for(int i=0;i<169;i++)
	{
		if(V[i]->Get_x()<=posx && V[i]->Get_x()+V[i]->Get_size()>=posx &&
			V[i]->Get_y()<=posy && V[i]->Get_y()+V[i]->Get_size()>=posy &&
			V[i]->Get_tipo()!=2 && V[i]->Get_tipo()!=3)
			validado=true;
		if(V[i]->Get_x()<=posx2 && V[i]->Get_x()+V[i]->Get_size()>=posx2 &&
			V[i]->Get_y()<=posy2 && V[i]->Get_y()+V[i]->Get_size()>=posy2 &&
			V[i]->Get_tipo()!=2 && V[i]->Get_tipo()!=3)
			validado2=true;
	}

	if(validado && validado2)
		return true;
	else
		return false;
}
bool CVecEspacios::ValidarMovimientoPersonaje(int tipo,int posx,int posy,int posx2,int posy2)
{
	bool validado=false;
	bool validado2=false;
	if(tipo==1)
	{
		for(int i=0;i<169;i++)
		{
			if(V[i]->Get_x()<=posx && V[i]->Get_x()+V[i]->Get_size()>=posx &&
				V[i]->Get_y()<=posy && V[i]->Get_y()+V[i]->Get_size()>=posy &&
				V[i]->Get_tipo()!=2 && V[i]->Get_tipo()!=3 && V[i]->Get_tipo()!=4 && V[i]->Get_tipo()!=5)
				validado=true;
			if(V[i]->Get_x()<=posx2 && V[i]->Get_x()+V[i]->Get_size()>=posx2 &&
				V[i]->Get_y()<=posy2 && V[i]->Get_y()+V[i]->Get_size()>=posy2 &&
				V[i]->Get_tipo()!=2 && V[i]->Get_tipo()!=3 && V[i]->Get_tipo()!=4 && V[i]->Get_tipo()!=5 && V[i]->Get_tipo()!=6)
				validado2=true;
		}
	}
	if(tipo==2)
	{
		for(int i=0;i<169;i++)
		{
			if(V[i]->Get_x()<=posx && V[i]->Get_x()+V[i]->Get_size()>=posx &&
				V[i]->Get_y()<=posy && V[i]->Get_y()+V[i]->Get_size()>=posy &&
				V[i]->Get_tipo()!=3 && V[i]->Get_tipo()!=4 && V[i]->Get_tipo()!=5 && V[i]->Get_tipo()!=6)
				validado=true;
			if(V[i]->Get_x()<=posx2 && V[i]->Get_x()+V[i]->Get_size()>=posx2 &&
				V[i]->Get_y()<=posy2 && V[i]->Get_y()+V[i]->Get_size()>=posy2 &&
				V[i]->Get_tipo()!=3 && V[i]->Get_tipo()!=4 && V[i]->Get_tipo()!=5 && V[i]->Get_tipo()!=6)
				validado2=true;
		}
	}

	if(validado && validado2)
		return true;
	else
		return false;
}
int CVecEspacios::ObtienePoder1(int posx,int posy,int posx2,int posy2)
{
	int poder1=0;
	int aux_poder1=0;

	int indice;

	for(int i=0;i<169;i++)
	{
		if(V[i]->Get_x()<=posx && V[i]->Get_x()+V[i]->Get_size()>=posx &&
			V[i]->Get_y()<=posy && V[i]->Get_y()+V[i]->Get_size()>=posy &&
			V[i]->Get_tipo()==4)
		{
			indice=i;
			poder1=1;
		}
		if(V[i]->Get_x()<=posx2 && V[i]->Get_x()+V[i]->Get_size()>=posx2 &&
			V[i]->Get_y()<=posy2 && V[i]->Get_y()+V[i]->Get_size()>=posy2 &&
			V[i]->Get_tipo()==4)
		{
			indice=i;
			aux_poder1=1;
		}
	}

	if(poder1==aux_poder1)
	{
		V[indice]->Set_tipo(1);
		return poder1;
	}
	else
		return 0;
}
int CVecEspacios::ObtienePoder2(int posx,int posy,int posx2,int posy2)
{
	int poder2=0;
	int aux_poder2=0;

	int indice;

	for(int i=0;i<169;i++)
	{
		if(V[i]->Get_x()<=posx && V[i]->Get_x()+V[i]->Get_size()>=posx &&
			V[i]->Get_y()<=posy && V[i]->Get_y()+V[i]->Get_size()>=posy &&
			V[i]->Get_tipo()==5)
		{
			indice=i;
			poder2=2;
		}
		if(V[i]->Get_x()<=posx2 && V[i]->Get_x()+V[i]->Get_size()>=posx2 &&
			V[i]->Get_y()<=posy2 && V[i]->Get_y()+V[i]->Get_size()>=posy2 &&
			V[i]->Get_tipo()==5)
	
		{
			indice=i;
			aux_poder2=2;
		}
	}
	
	if(poder2==aux_poder2)
	{
		V[indice]->Set_tipo(1);
		return poder2;
	}
	else
		return 0;
}
bool CVecEspacios::CruzaPuerta(int n,int m)
{
	if(V[22]->Get_tipo()==6)
		//if(n >= V[22]->Get_x() && n < V[22]->Get_x() + V[22]->Get_size() &&
		//	m >= V[22]->Get_y() && m < V[22]->Get_y() + V[22]->Get_size())
			if (n == V[22]->Get_x() && m == V[22]->Get_y())
		
			return true;
	return false;
}