#pragma once


namespace Bloques {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Form1
	///
	/// ADVERTENCIA: si cambia el nombre de esta clase, deber� cambiar la
	///          propiedad 'Nombre de archivos de recursos' de la herramienta de compilaci�n de recursos administrados
	///          asociada con todos los archivos .resx de los que depende esta clase. De lo contrario,
	///          los dise�adores no podr�n interactuar correctamente con los
	///          recursos adaptados asociados con este formulario.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	private:
		System::Random ^R;
		CVecEspacios *Blocks1;
		CVecEspacios *Blocks2;
		CVecEnemigos *Enemies1;
		CVecEnemigos *Enemies2;
		CBombas *Bombs;
		CBombas *Bombs2;
		CBomber *Player;
		System::Drawing::Bitmap ^BloqueNormal;
		System::Drawing::Bitmap ^BloqueObstaculo;
		System::Drawing::Bitmap ^BloquePoder1;
		System::Drawing::Bitmap ^BloquePoder2;
		System::Drawing::Bitmap ^BloquePuerta;
		System::Drawing::Bitmap ^Bomba;
		System::Drawing::Bitmap ^BombaBoom;
		System::Drawing::Bitmap ^ImgPlayer;
		System::Drawing::Bitmap ^ImgEnemigo1;
		System::Drawing::Bitmap ^ImgEnemigo2;
		System::Drawing::Font ^F;
		System::Drawing::SolidBrush ^B;
	private: System::Windows::Forms::PictureBox^  pictureBox4;
	private: System::Windows::Forms::PictureBox^  pictureBox5;
	private: System::Windows::Forms::PictureBox^  pictureBox6;
	private: System::Windows::Forms::PictureBox^  pictureBox7;
	private: System::Windows::Forms::PictureBox^  pictureBox8;
	private: System::Windows::Forms::PictureBox^  pictureBox9;
	private: System::Windows::Forms::PictureBox^  pictureBox10;
	private: System::Windows::Forms::Timer^  timer2;
	private: System::Windows::Forms::Timer^  timer3;
	private: System::Windows::Forms::Timer^  timer4;
	private: System::Windows::Forms::PictureBox^  pictureBox11;
	private: System::Windows::Forms::PictureBox^  pictureBox12;
	private: System::Windows::Forms::PictureBox^  pictureBox13;
	private: System::Windows::Forms::PictureBox^  pictureBox14;
			 System::Drawing::Bitmap ^BloqueMuro;
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	protected: 
	private: System::Windows::Forms::PictureBox^  pictureBox2;
	private: System::Windows::Forms::PictureBox^  pictureBox3;
	private: System::Windows::Forms::Timer^  timer1;
	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox3 = (gcnew System::Windows::Forms::PictureBox());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->pictureBox4 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox5 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox6 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox7 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox8 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox9 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox10 = (gcnew System::Windows::Forms::PictureBox());
			this->timer2 = (gcnew System::Windows::Forms::Timer(this->components));
			this->timer3 = (gcnew System::Windows::Forms::Timer(this->components));
			this->timer4 = (gcnew System::Windows::Forms::Timer(this->components));
			this->pictureBox11 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox12 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox13 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox14 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox5))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox6))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox7))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox8))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox9))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox10))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox11))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox12))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox13))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox14))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(12, 12);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(50, 50);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox1->TabIndex = 0;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Visible = false;
			// 
			// pictureBox2
			// 
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(68, 12);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(50, 50);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox2->TabIndex = 1;
			this->pictureBox2->TabStop = false;
			this->pictureBox2->Visible = false;
			// 
			// pictureBox3
			// 
			this->pictureBox3->BackColor = System::Drawing::Color::Gray;
			this->pictureBox3->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox3.Image")));
			this->pictureBox3->Location = System::Drawing::Point(124, 12);
			this->pictureBox3->Name = L"pictureBox3";
			this->pictureBox3->Size = System::Drawing::Size(50, 50);
			this->pictureBox3->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox3->TabIndex = 2;
			this->pictureBox3->TabStop = false;
			this->pictureBox3->Visible = false;
			// 
			// timer1
			// 
			this->timer1->Tick += gcnew System::EventHandler(this, &Form1::timer1_Tick);
			// 
			// pictureBox4
			// 
			this->pictureBox4->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox4.Image")));
			this->pictureBox4->Location = System::Drawing::Point(12, 198);
			this->pictureBox4->Name = L"pictureBox4";
			this->pictureBox4->Size = System::Drawing::Size(900, 25);
			this->pictureBox4->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox4->TabIndex = 3;
			this->pictureBox4->TabStop = false;
			this->pictureBox4->Visible = false;
			// 
			// pictureBox5
			// 
			this->pictureBox5->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox5.Image")));
			this->pictureBox5->Location = System::Drawing::Point(12, 274);
			this->pictureBox5->Name = L"pictureBox5";
			this->pictureBox5->Size = System::Drawing::Size(160, 25);
			this->pictureBox5->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox5->TabIndex = 4;
			this->pictureBox5->TabStop = false;
			this->pictureBox5->Visible = false;
			// 
			// pictureBox6
			// 
			this->pictureBox6->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox6.Image")));
			this->pictureBox6->Location = System::Drawing::Point(12, 68);
			this->pictureBox6->Name = L"pictureBox6";
			this->pictureBox6->Size = System::Drawing::Size(150, 200);
			this->pictureBox6->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox6->TabIndex = 5;
			this->pictureBox6->TabStop = false;
			this->pictureBox6->Visible = false;
			// 
			// pictureBox7
			// 
			this->pictureBox7->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox7.Image")));
			this->pictureBox7->Location = System::Drawing::Point(168, 68);
			this->pictureBox7->Name = L"pictureBox7";
			this->pictureBox7->Size = System::Drawing::Size(150, 200);
			this->pictureBox7->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox7->TabIndex = 6;
			this->pictureBox7->TabStop = false;
			this->pictureBox7->Visible = false;
			// 
			// pictureBox8
			// 
			this->pictureBox8->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox8.Image")));
			this->pictureBox8->Location = System::Drawing::Point(322, 68);
			this->pictureBox8->Name = L"pictureBox8";
			this->pictureBox8->Size = System::Drawing::Size(150, 200);
			this->pictureBox8->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox8->TabIndex = 7;
			this->pictureBox8->TabStop = false;
			this->pictureBox8->Visible = false;
			// 
			// pictureBox9
			// 
			this->pictureBox9->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox9.Image")));
			this->pictureBox9->Location = System::Drawing::Point(180, 12);
			this->pictureBox9->Name = L"pictureBox9";
			this->pictureBox9->Size = System::Drawing::Size(50, 50);
			this->pictureBox9->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox9->TabIndex = 8;
			this->pictureBox9->TabStop = false;
			this->pictureBox9->Visible = false;
			// 
			// pictureBox10
			// 
			this->pictureBox10->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox10.Image")));
			this->pictureBox10->Location = System::Drawing::Point(236, 12);
			this->pictureBox10->Name = L"pictureBox10";
			this->pictureBox10->Size = System::Drawing::Size(50, 50);
			this->pictureBox10->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox10->TabIndex = 9;
			this->pictureBox10->TabStop = false;
			this->pictureBox10->Visible = false;
			// 
			// timer2
			// 
			this->timer2->Tick += gcnew System::EventHandler(this, &Form1::timer2_Tick);
			// 
			// timer3
			// 
			this->timer3->Tick += gcnew System::EventHandler(this, &Form1::timer3_Tick);
			// 
			// timer4
			// 
			this->timer4->Tick += gcnew System::EventHandler(this, &Form1::timer4_Tick);
			// 
			// pictureBox11
			// 
			this->pictureBox11->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox11.Image")));
			this->pictureBox11->Location = System::Drawing::Point(292, 12);
			this->pictureBox11->Name = L"pictureBox11";
			this->pictureBox11->Size = System::Drawing::Size(50, 50);
			this->pictureBox11->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox11->TabIndex = 10;
			this->pictureBox11->TabStop = false;
			this->pictureBox11->Visible = false;
			// 
			// pictureBox12
			// 
			this->pictureBox12->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox12.Image")));
			this->pictureBox12->Location = System::Drawing::Point(478, 68);
			this->pictureBox12->Name = L"pictureBox12";
			this->pictureBox12->Size = System::Drawing::Size(100, 50);
			this->pictureBox12->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox12->TabIndex = 11;
			this->pictureBox12->TabStop = false;
			this->pictureBox12->Visible = false;
			// 
			// pictureBox13
			// 
			this->pictureBox13->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox13.Image")));
			this->pictureBox13->Location = System::Drawing::Point(478, 124);
			this->pictureBox13->Name = L"pictureBox13";
			this->pictureBox13->Size = System::Drawing::Size(100, 50);
			this->pictureBox13->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox13->TabIndex = 12;
			this->pictureBox13->TabStop = false;
			this->pictureBox13->Visible = false;
			// 
			// pictureBox14
			// 
			this->pictureBox14->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox14.Image")));
			this->pictureBox14->Location = System::Drawing::Point(478, 2);
			this->pictureBox14->Name = L"pictureBox14";
			this->pictureBox14->Size = System::Drawing::Size(100, 50);
			this->pictureBox14->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox14->TabIndex = 13;
			this->pictureBox14->TabStop = false;
			this->pictureBox14->Visible = false;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(670, 670);
			this->Controls->Add(this->pictureBox14);
			this->Controls->Add(this->pictureBox13);
			this->Controls->Add(this->pictureBox12);
			this->Controls->Add(this->pictureBox11);
			this->Controls->Add(this->pictureBox10);
			this->Controls->Add(this->pictureBox9);
			this->Controls->Add(this->pictureBox8);
			this->Controls->Add(this->pictureBox7);
			this->Controls->Add(this->pictureBox6);
			this->Controls->Add(this->pictureBox5);
			this->Controls->Add(this->pictureBox4);
			this->Controls->Add(this->pictureBox3);
			this->Controls->Add(this->pictureBox2);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"Form1";
			this->Text = L"Bomberman";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->MouseClick += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::Form1_MouseClick);
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &Form1::Form1_FormClosing);
			this->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Form1::Form1_KeyDown);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox5))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox6))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox7))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox8))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox9))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox10))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox11))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox12))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox13))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox14))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
				 R=gcnew System::Random((int)System::DateTime::Now.Ticks);

				 BloqueNormal=gcnew System::Drawing::Bitmap(this->pictureBox1->Image);
				 BloqueObstaculo=gcnew System::Drawing::Bitmap(this->pictureBox2->Image);
				 BloqueMuro=gcnew System::Drawing::Bitmap(this->pictureBox3->Image);
				 BloquePoder1=gcnew System::Drawing::Bitmap(this->pictureBox9->Image);
				 BloquePoder2=gcnew System::Drawing::Bitmap(this->pictureBox10->Image);
				 BloquePuerta=gcnew System::Drawing::Bitmap(this->pictureBox11->Image);

				 Bomba=gcnew System::Drawing::Bitmap(this->pictureBox4->Image);
				 Bomba->MakeTransparent(Bomba->GetPixel(1,1));
				 BombaBoom=gcnew System::Drawing::Bitmap(this->pictureBox5->Image);
				 BombaBoom->MakeTransparent(BombaBoom->GetPixel(1,1));

				 ImgPlayer=gcnew System::Drawing::Bitmap(this->pictureBox6->Image);
				 ImgPlayer->MakeTransparent(ImgPlayer->GetPixel(1,1));
				 ImgEnemigo1=gcnew System::Drawing::Bitmap(this->pictureBox7->Image);
				 ImgEnemigo1->MakeTransparent(ImgEnemigo1->GetPixel(1,1));
				 ImgEnemigo2=gcnew System::Drawing::Bitmap(this->pictureBox8->Image);
				 ImgEnemigo2->MakeTransparent(ImgEnemigo2->GetPixel(1,1));

				 Blocks1=new CVecEspacios(1);
				 Blocks2=new CVecEspacios(2);
				 Enemies1=new CVecEnemigos(R,5,5,0,2);
				 Enemies2=new CVecEnemigos(R,5,5,0,2);
				 Bombs=new CBombas();
				 Bombs2=new CBombas();
				 Player=new CBomber(10,10,5,5,50,50,0,2);

				 F=gcnew System::Drawing::Font("Arial",15);
				 B=gcnew System::Drawing::SolidBrush(System::Drawing::Color::Black);

				 this->timer4->Enabled=true;
				 this->timer4->Interval=50;
			 }
// NIVEL1 ----- NIVEL1 ----- NIVEL1 ----- NIVEL1 ----- NIVEL1 ----- NIVEL1 ----- NIVEL1
	private: System::Void timer1_Tick(System::Object^  sender, System::EventArgs^  e) {
				 Graphics ^g = this->CreateGraphics();
				 int gWidth = (int)g->VisibleClipBounds.Width;
				 int gHeight = (int)g->VisibleClipBounds.Height;
				 BufferedGraphicsContext ^espacioBuffer = BufferedGraphicsManager::Current;
				 espacioBuffer->MaximumBuffer = System::Drawing::Size( gWidth + 1, gHeight + 1 );
				 BufferedGraphics ^buffer = espacioBuffer->Allocate( g, Drawing::Rectangle(0, 0, gWidth, gHeight));

				 buffer->Graphics->Clear(this->BackColor);
				 Blocks1->Mostrar(buffer->Graphics,BloqueNormal,BloqueObstaculo,BloqueMuro,BloquePoder1,BloquePoder2,BloquePuerta);
				 Enemies1->Mostrar(buffer->Graphics,ImgEnemigo1,ImgEnemigo2);
				 Player->Mostrar(buffer->Graphics,ImgPlayer);
				 Bombs->MostrarBombas(buffer->Graphics,Bomba,BombaBoom);
				 buffer->Graphics->DrawString("Vidas : "+Player->Get_vidas().ToString(),F,B,0,0);
				 buffer->Graphics->DrawString("Puntos : "+Player->Get_puntaje().ToString(),F,B,500,650);

				 buffer->Render(g);

				 if(Blocks1->DestruccionDeBloqueBoom(R,Bombs))
					 Player->Set_puntaje(Player->Get_puntaje()+100);
				 if(Enemies1->PierdeContraBomba(Bombs))
					 Player->Set_puntaje(Player->Get_puntaje()+500);
				 Enemies1->Mover(R,gWidth,gHeight,Blocks1,Bombs);
				 Bombs->Borrar1Bomba();

				 delete buffer;
				 delete espacioBuffer;
				 delete g;

				 if(Player->PierdeContraBomba(Bombs) || Player->PierdeContraEnemigo(Enemies1))
				 {
					 if(Player->Get_vidas()==0)
					 {
						 this->timer1->Enabled=false;
						 this->timer3->Enabled=true;
						 this->timer3->Interval=50;
					 }
					 else
					 {
						 Player->Set_vidas(Player->Get_vidas()-1);
						 Player->Reiniciarposicion();
					 }
				 }
				 
				 if(Player->GanaNivel(Enemies1,Blocks1))
				 {
					 this->timer1->Enabled=false;
					 Player->Reiniciarposicion();
					 this->timer2->Enabled=true;
					 this->timer2->Interval=50;
				 }
			 }
private: System::Void Form1_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e) {
			 delete R;

			 delete BloqueNormal;
			 delete BloqueObstaculo;
			 delete BloqueMuro;

			 delete Bomba;
			 delete BombaBoom;

			 delete ImgPlayer;
			 delete ImgEnemigo1;
			 delete ImgEnemigo2;

			 delete Blocks1;
			 delete Blocks2;
			 delete Enemies1;
			 delete Enemies2;
			 delete Player;
			 delete Bombs;

			 delete F;
			 delete B;
		 }
private: System::Void Form1_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
			 if(this->timer1->Enabled==true)
				 switch(e->KeyCode)
			 {
				 case Keys::Up:
					 Player->Mover(1,this->ClientSize.Width-10,this->ClientSize.Height-10,Blocks1,Bombs);
					 break;
				 case Keys::Right:
					 Player->Mover(2,this->ClientSize.Width-10,this->ClientSize.Height-10,Blocks1,Bombs);
					 break;
				 case Keys::Down:
					 Player->Mover(3,this->ClientSize.Width-10,this->ClientSize.Height-10,Blocks1,Bombs);
					 break;
				 case Keys::Left:
					 Player->Mover(4,this->ClientSize.Width-10,this->ClientSize.Height-10,Blocks1,Bombs);
					 break;
				 case Keys::ShiftKey:
					 Player->PonerBomba(Bombs);
					 break;
			 }

			 if(this->timer2->Enabled==true)
				 switch(e->KeyCode)
			 {
				 case Keys::Up:
					 Player->Mover(1,this->ClientSize.Width-10,this->ClientSize.Height-10,Blocks2,Bombs2);
					 break;
				 case Keys::Right:
					 Player->Mover(2,this->ClientSize.Width-10,this->ClientSize.Height-10,Blocks2,Bombs2);
					 break;
				 case Keys::Down:
					 Player->Mover(3,this->ClientSize.Width-10,this->ClientSize.Height-10,Blocks2,Bombs2);
					 break;
				 case Keys::Left:
					 Player->Mover(4,this->ClientSize.Width-10,this->ClientSize.Height-10,Blocks2,Bombs2);
					 break;
				 case Keys::ShiftKey:
					 Player->PonerBomba(Bombs2);
					 break;
			 }

			 if(this->timer3->Enabled==true)
				 if(e->KeyCode==Keys::Escape)
					this->Close();
		 }
		 
// NIVEL2 ----- NIVEL2 ----- NIVEL2 ----- NIVEL2 ----- NIVEL2 ----- NIVEL2 ----- NIVEL2
private: System::Void timer2_Tick(System::Object^  sender, System::EventArgs^  e) {
				 Graphics ^g = this->CreateGraphics();
				 int gWidth = (int)g->VisibleClipBounds.Width;
				 int gHeight = (int)g->VisibleClipBounds.Height;
				 BufferedGraphicsContext ^espacioBuffer = BufferedGraphicsManager::Current;
				 espacioBuffer->MaximumBuffer = System::Drawing::Size( gWidth + 1, gHeight + 1 );
				 BufferedGraphics ^buffer = espacioBuffer->Allocate( g, Drawing::Rectangle(0, 0, gWidth, gHeight));

				 buffer->Graphics->Clear(this->BackColor);
				 Blocks2->Mostrar(buffer->Graphics,BloqueNormal,BloqueObstaculo,BloqueMuro,BloquePoder1,BloquePoder2,BloquePuerta);
				 Enemies2->Mostrar(buffer->Graphics,ImgEnemigo1,ImgEnemigo2);
				 Player->Mostrar(buffer->Graphics,ImgPlayer);
				 Bombs2->MostrarBombas(buffer->Graphics,Bomba,BombaBoom);
				 buffer->Graphics->DrawString("Puntos : "+Player->Get_puntaje().ToString(),F,B,500,650);

				 buffer->Render(g);
				 Bombs2->Borrar1Bomba();
				 Enemies2->Mover(R,gWidth,gHeight,Blocks2,Bombs2);

				 if(Blocks2->DestruccionDeBloqueBoom(R,Bombs2))
					 Player->Set_puntaje(Player->Get_puntaje()+100);
				 if(Enemies2->PierdeContraBomba(Bombs2))
					 Player->Set_puntaje(Player->Get_puntaje()+500);

				 delete buffer;
				 delete espacioBuffer;
				 delete g;

				 if(Player->PierdeContraBomba(Bombs2) || Player->PierdeContraEnemigo(Enemies2))
				 {
					 if(Player->Get_vidas()==0)
					 {
						 this->timer2->Enabled=false;
						 this->timer3->Enabled=true;
						 this->timer3->Interval=50;
					 }
					 else
					 {
						 Player->Set_vidas(Player->Get_vidas()-1);
						 Player->Reiniciarposicion();
					 }
				 }

				 if(Player->GanaNivel(Enemies2,Blocks2))
				 {
					 this->timer2->Enabled=false;
					 Player->Reiniciarposicion();
					 this->timer3->Enabled=true;
					 this->timer3->Interval=50;
				 }
			 }
// FIN ----- FIN ----- FIN ----- FIN ----- FIN ----- FIN ----- FIN
private: System::Void timer3_Tick(System::Object^  sender, System::EventArgs^  e) {
					  Graphics ^g = this->CreateGraphics();
					  int gWidth = (int)g->VisibleClipBounds.Width;
					  int gHeight = (int)g->VisibleClipBounds.Height;
					  BufferedGraphicsContext ^espacioBuffer = BufferedGraphicsManager::Current;
					  espacioBuffer->MaximumBuffer = System::Drawing::Size( gWidth + 1, gHeight + 1 );
					  BufferedGraphics ^buffer = espacioBuffer->Allocate( g, Drawing::Rectangle(0, 0, gWidth, gHeight));

					  buffer->Graphics->DrawImage(this->pictureBox14->Image,0,0,gWidth,gHeight);
					  buffer->Graphics->DrawString("Puntaje Final : "+Player->Get_puntaje().ToString(),F,B,150,480);

					  buffer->Render(g);

					  delete buffer;
					  delete espacioBuffer;
					  delete g;
				  }
// INICIO ----- INICIO ----- INICIO ----- INICIO ----- INICIO ----- INICIO ----- INICIO
private: System::Void timer4_Tick(System::Object^  sender, System::EventArgs^  e) {

Graphics ^g = this->CreateGraphics();

int gWidth = (int)g->VisibleClipBounds.Width;
int gHeight = (int)g->VisibleClipBounds.Height;

BufferedGraphicsContext ^espacioBuffer = BufferedGraphicsManager::Current;

espacioBuffer->MaximumBuffer = System::Drawing::Size( gWidth + 1, gHeight + 1 );

BufferedGraphics ^buffer = espacioBuffer->Allocate( g, Drawing::Rectangle(0, 0, gWidth, gHeight));

System::Drawing::Bitmap ^imgTransparente = gcnew System::Drawing::Bitmap(this->pictureBox13->Image);
imgTransparente->MakeTransparent(imgTransparente->GetPixel(1,1));

buffer->Graphics->DrawImage(this->pictureBox12->Image,0,0,gWidth,gHeight);
buffer->Graphics->DrawImage(imgTransparente,150,480,400,150);

buffer->Render(g);

delete g;
delete buffer;
delete imgTransparente;
		 }

private: System::Void Form1_MouseClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
			 if(e->X>=150 && e->X<=550 && e->Y>=480 && e->Y<=630 && this->timer4->Enabled==true)
			 {
				 this->timer4->Enabled=false;
				 this->timer1->Enabled=true;
				 this->timer1->Interval=50;
			 }
		 }
};
}

