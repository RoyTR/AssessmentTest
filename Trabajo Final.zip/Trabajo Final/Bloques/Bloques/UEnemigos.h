class CPersonaje
{
protected:
	int x;
	int y;
	int dx;
	int dy;
	int anchoB;
	int altoB;
	int Indice1;
	int Indice2;
	int tipo;
public:
	CPersonaje(int x,int y,int dx,int dy,int anchoB,int altoB,int Indice1,int Indice2,int tipo);
	~CPersonaje();
	void Mover(int direccion,int ancho,int alto,CVecEspacios *P,CBombas *Q);
	virtual void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2) abstract;
	bool PierdeContraBomba(CBombas *P);
	int Get_x();
	int Get_y();
	int Get_anchoB();
	int Get_altoB();
};

//////

class CEnemigo1:public CPersonaje
{
public:
	CEnemigo1(int x,int y,int dx,int dy,int anchoB,int altoB,int Indice1,int Indice2,int tipo);
	~CEnemigo1();
	void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2);
};

class CEnemigo2:public CPersonaje
{
public:
	CEnemigo2(int x,int y,int dx,int dy,int anchoB,int altoB,int Indice1,int Indice2,int tipo);
	~CEnemigo2();
	void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2);
};

//////////////////////

class CVecEnemigos
{
private:
	int n;
	CPersonaje **V;

	int intervalo;
	int direccion;
public:
	CVecEnemigos(System::Random ^R,int dx,int dy,int Indice1,int Indice2);
	~CVecEnemigos();
	void Mover(System::Random ^R,int ancho,int alto,CVecEspacios *P,CBombas *Q);
	void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2);
	bool PierdeContraBomba(CBombas *P);
	bool ValidarMataBomber(int x,int y,int an,int al);
	int Get_n();
};