#include "stdafx.h"

CBomber::CBomber(int x,int y,int dx,int dy,int anchoB,int altoB,int Indice1,int Indice2)
{
	this->x=x;
	this->y=y;
	this->dx=dx;
	this->dy=dy;
	this->anchoB=anchoB;
	this->altoB=altoB;
	this->Indice1=Indice1;
	this->Indice2=Indice2;
	this->vidas=2;
	this->puntaje=0;
}
CBomber::~CBomber()
{
}
void CBomber::Mover(int direccion,int ancho,int alto,CVecEspacios *P,CBombas *O)
{
	switch(direccion)
	{
		//Arriba
	case 1:
		Indice2=0;
		if(y-dy>=10)
			if(P->ValidarMovimiento(x,y-dy,x+anchoB,y-dy))
			{
				if(P->ObtienePoder1(x,y-dy,x+anchoB,y-dy)==1)
					O->Set_n(O->Get_n()+1);
				if(P->ObtienePoder2(x,y-dy,x+anchoB,y-dy)==2)
					O->Set_ALCANCE(O->Get_ALCANCE()+1);
				y-=dy;
			}
		break;
		//Derecha
	case 2:
		Indice2=1;
		if(x+dx+anchoB<=ancho)
			if(P->ValidarMovimiento(x+anchoB+dx,y,x+anchoB+dx,y+altoB))
			{
				if(P->ObtienePoder1(x+anchoB+dx,y,x+anchoB+dx,y+altoB)==1)
					O->Set_n(O->Get_n()+1);
				if(P->ObtienePoder2(x+anchoB+dx,y,x+anchoB+dx,y+altoB)==2)
					O->Set_ALCANCE(O->Get_ALCANCE()+1);
				x+=dx;
			}
		break;
		//Abajo
	case 3:
		Indice2=2;
		if(y+dy+altoB<=alto)
			if(P->ValidarMovimiento(x,y+altoB+dy,x+anchoB,y+altoB+dy))
			{
				if(P->ObtienePoder1(x,y+altoB+dy,x+anchoB,y+altoB+dy)==1)
					O->Set_n(O->Get_n()+1);
				if(P->ObtienePoder2(x,y+altoB+dy,x+anchoB,y+altoB+dy)==2)
					O->Set_ALCANCE(O->Get_ALCANCE()+1);
				y+=dy;
			}
		break;
		//Izquierda
	case 4:
		Indice2=3;
		if(x-dx>=10)
			if(P->ValidarMovimiento(x-dx,y,x-dx,y+altoB))
			{
				if(P->ObtienePoder1(x-dx,y,x-dx,y+altoB)==1)
					O->Set_n(O->Get_n()+1);
				if(P->ObtienePoder2(x-dx,y,x-dx,y+altoB)==2)
					O->Set_ALCANCE(O->Get_ALCANCE()+1);		
				x-=dx;
			}
		break;
	}
}
void CBomber::PonerBomba(CBombas *P)
{
	P->Poner1Bomba(x,y);
}
void CBomber::Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp)
{
	int anchoFrame=bmp->Width/3;
	int altoFrame=bmp->Height/4;

	System::Drawing::Rectangle ZonaaDibujar(x,y,anchoB,altoB);
	System::Drawing::Rectangle ZonaaUsar(Indice1*anchoFrame,Indice2*altoFrame,anchoFrame,altoFrame);

	C->DrawImage(bmp,ZonaaDibujar,ZonaaUsar,System::Drawing::GraphicsUnit::Pixel);
	//C->DrawImage(imgTransparente,Rectangle(pox,poy,120,120)ZonaaaUsar,GraphicsUnit::Pixel);

	if(Indice1==2)
		Indice1=0;
	else
		Indice1++;
}
bool CBomber::PierdeContraBomba(CBombas *P)
{
	return P->ValidarMuertePorExplosion(x,y,anchoB,altoB);
}
bool CBomber::PierdeContraEnemigo(CVecEnemigos *P)
{
	return P->ValidarMataBomber(x,y,anchoB,altoB);
}
bool CBomber::GanaNivel(CVecEnemigos *P,CVecEspacios *Q)
{
	if(P->Get_n()==0 && Q->CruzaPuerta(x,y))
		return true;
	else
		return false;
}
void CBomber::Reiniciarposicion()
{
	x=10;
	y=10;
}
int CBomber::Get_vidas()
{
	return vidas;
}
void CBomber::Set_vidas(int vidas)
{
	this->vidas=vidas;
}
int CBomber::Get_puntaje()
{
	return puntaje;
}
void CBomber::Set_puntaje(int puntaje)
{
	this->puntaje=puntaje;
}