========================================================================
    APLICACI�N: Informaci�n general del proyecto Bloques
========================================================================

AppWizard ha creado esta aplicaci�n Bloques.  

Este archivo incluye un resumen acerca del contenido de los archivos que
constituyen su aplicaci�n Bloques.

Bloques.vcproj
    �ste es el archivo de proyecto principal para los proyectos de VC++
    generados mediante un Asistente para aplicaciones. 
    Contiene informaci�n acerca de la versi�n de Visual C++ con la que
    se gener� el archivo, as� como informaci�n acerca de las plataformas,
    configuraciones y caracter�sticas del proyecto seleccionadas en el
    Asistente para aplicaciones.

Bloques.cpp
    �sta es la aplicaci�n principal del archivo de c�digo fuente.
    Contiene el c�digo para mostrar el formulario.

Form1.h
    Contiene la implementaci�n de su clase de formulario y funci�n 
    InitializeComponent().

AssemblyInfo.cpp
    Contiene atributos personalizados para modificar metadatos de 
    ensamblado.

/////////////////////////////////////////////////////////////////////////////
Otros archivos est�ndar:

StdAfx.h, StdAfx.cpp
    Estos archivos se utilizan para generar un archivo de encabezado 
    precompilado (PCH) denominado Bloques.pch y un archivo de 
    tipos precompilado denominado StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
