class CBomber
{
protected:
	int x;
	int y;
	int dx;
	int dy;
	int anchoB;
	int altoB;
	int Indice1;
	int Indice2;
	int vidas;
	int puntaje;
public:
	CBomber(int x,int y,int dx,int dy,int anchoB,int altoB,int Indice1,int Indice2);
	~CBomber();
	void Mover(int direccion,int ancho,int alto,CVecEspacios *P,CBombas *O);
	void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp);
	void PonerBomba(CBombas *P);
	bool PierdeContraBomba(CBombas *P);
	bool PierdeContraEnemigo(CVecEnemigos *P);
	bool GanaNivel(CVecEnemigos *P,CVecEspacios *Q);
	void Reiniciarposicion();
	int Get_vidas();
	void Set_vidas(int vidas);
	int Get_puntaje();
	void Set_puntaje(int puntaje);
};