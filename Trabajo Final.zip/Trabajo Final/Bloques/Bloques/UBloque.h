class CEspacio
{
protected:
	int x;
	int y;
	int size;
	int tipo;
public:
	CEspacio(int x,int y,int size,int tipo);
	~CEspacio();
	void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2,System::Drawing::Bitmap ^bmp3,System::Drawing::Bitmap ^bmp4,System::Drawing::Bitmap ^bmp5,System::Drawing::Bitmap ^bmp6);
	void Set_tipo(int tipo);
	int Get_x();
	int Get_y();
	int Get_size();
	int Get_tipo();
};

class CNormal:public CEspacio
{
public:
	CNormal(int x,int y,int size,int tipo);
	~CNormal();
	//void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2,System::Drawing::Bitmap ^bmp3,System::Drawing::Bitmap ^bmp4,System::Drawing::Bitmap ^bmp5,System::Drawing::Bitmap ^bmp6);
};

class CObstaculo:public CEspacio
{
public:
	CObstaculo(int x,int y,int size,int tipo);
	~CObstaculo();
	//void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2,System::Drawing::Bitmap ^bmp3,System::Drawing::Bitmap ^bmp4,System::Drawing::Bitmap ^bmp5,System::Drawing::Bitmap ^bmp6);
};

class CMuro:public CEspacio
{
public:
	CMuro(int x,int y,int size,int tipo);
	~CMuro();
	//void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2,System::Drawing::Bitmap ^bmp3,System::Drawing::Bitmap ^bmp4,System::Drawing::Bitmap ^bmp5,System::Drawing::Bitmap ^bmp6);
};

class CPoder1:public CEspacio
{
public:
	CPoder1(int x,int y,int size,int tipo);
	~CPoder1();
	//void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2,System::Drawing::Bitmap ^bmp3,System::Drawing::Bitmap ^bmp4,System::Drawing::Bitmap ^bmp5,System::Drawing::Bitmap ^bmp6);
};

class CPoder2:public CEspacio
{
public:
	CPoder2(int x,int y,int size,int tipo);
	~CPoder2();
	//void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2,System::Drawing::Bitmap ^bmp3,System::Drawing::Bitmap ^bmp4,System::Drawing::Bitmap ^bmp5,System::Drawing::Bitmap ^bmp6);
};

class CPuerta:public CEspacio
{
public:
	CPuerta(int x,int y,int size,int tipo);
	~CPuerta();
	//void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2,System::Drawing::Bitmap ^bmp3,System::Drawing::Bitmap ^bmp4,System::Drawing::Bitmap ^bmp5,System::Drawing::Bitmap ^bmp6);
};

//////////

class CVecEspacios
{
private:
	int n;
	CEspacio **V;
public:
	CVecEspacios(int nivel);
	~CVecEspacios();
	void Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2,System::Drawing::Bitmap ^bmp3,System::Drawing::Bitmap ^bmp4,System::Drawing::Bitmap ^bmp5,System::Drawing::Bitmap ^bmp6);
	bool DestruccionDeBloqueBoom(System::Random ^R,CBombas *P);
	bool ValidarMovimiento(int posx,int posy,int posx2,int posy2);
	bool ValidarMovimientoPersonaje(int tipo,int posx,int posy,int posx2,int posy2);
	int ObtienePoder1(int posx,int posy,int posx2,int posy2);
	int ObtienePoder2(int posx,int posy,int posx2,int posy2);
	bool CruzaPuerta(int n,int m);
};