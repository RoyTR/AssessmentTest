#include "stdafx.h"

CPersonaje::CPersonaje(int x,int y,int dx,int dy,int anchoB,int altoB,int Indice1,int Indice2,int tipo)
{
	this->x=x;
	this->y=y;
	this->dx=dx;
	this->dy=dy;
	this->anchoB=anchoB;
	this->altoB=altoB;
	this->Indice1=Indice1;
	this->Indice2=Indice2;
	this->tipo=tipo;
}
CPersonaje::~CPersonaje()
{
}
void CPersonaje::Mover(int direccion,int ancho,int alto,CVecEspacios *P,CBombas *Q)
{
	switch(direccion)
	{
		//Arriba
	case 1:
		Indice2=0;
		if(y-dy>=10)
			if(P->ValidarMovimientoPersonaje(tipo,x,y-dy,x+anchoB,y-dy))
				if(Q->SobreBomba(x,y-dy,x+anchoB,y-dy,anchoB,altoB))
					y-=dy;
		break;
		//Derecha
	case 2:
		Indice2=1;
		if(x+dx+anchoB<=ancho)
			if(P->ValidarMovimientoPersonaje(tipo,x+anchoB+dx,y,x+anchoB+dx,y+altoB))
				if(Q->SobreBomba(x+anchoB+dx,y,x+anchoB+dx,y+altoB,anchoB,altoB))
					x+=dx;
		break;
		//Abajo
	case 3:
		Indice2=2;
		if(y+dy+altoB<=alto)
			if(P->ValidarMovimientoPersonaje(tipo,x,y+altoB+dy,x+anchoB,y+altoB+dy))
				if(Q->SobreBomba(x,y+altoB+dy,x+anchoB,y+altoB+dy,anchoB,altoB))
					y+=dy;
		break;
		//Izquierda
	case 4:
		Indice2=3;
		if(x-dx>=10)
			if(P->ValidarMovimientoPersonaje(tipo,x-dx,y,x-dx,y+altoB))
				if(Q->SobreBomba(x-dx,y,x-dx,y+altoB,anchoB,altoB))
					x-=dx;
		break;
	}
}
bool CPersonaje::PierdeContraBomba(CBombas *P)
{
	return P->ValidarMuertePorExplosion(x,y,anchoB,altoB);
}
int CPersonaje::Get_x()
{
	return x;
}
int CPersonaje::Get_y()
{
	return y;
}
int CPersonaje::Get_anchoB()
{
	return anchoB;
}
int CPersonaje::Get_altoB()
{
	return altoB;
}

//////////////////

CEnemigo1::CEnemigo1(int x,int y,int dx,int dy,int anchoB,int altoB,int Indice1,int Indice2,int tipo):CPersonaje(x,y,dx,dy,anchoB,altoB,Indice1,Indice2,tipo)
{
}
CEnemigo1::~CEnemigo1()
{
}
void CEnemigo1::Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2)
{
	int anchoFrame=bmp->Width/3;
	int altoFrame=bmp->Height/4;

	System::Drawing::Rectangle ZonaaDibujar(x,y,anchoB,altoB);
	System::Drawing::Rectangle ZonaaUsar(Indice1*anchoFrame,Indice2*altoFrame,anchoFrame,altoFrame);

	C->DrawImage(bmp,ZonaaDibujar,ZonaaUsar,System::Drawing::GraphicsUnit::Pixel);

	if(Indice1==2)
		Indice1=0;
	else
		Indice1++;
}

CEnemigo2::CEnemigo2(int x,int y,int dx,int dy,int anchoB,int altoB,int Indice1,int Indice2,int tipo):CPersonaje(x,y,dx,dy,anchoB,altoB,Indice1,Indice2,tipo)
{
}
CEnemigo2::~CEnemigo2()
{
}
void CEnemigo2::Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2)
{
	int anchoFrame=bmp2->Width/3;
	int altoFrame=bmp2->Height/4;

	System::Drawing::Rectangle ZonaaDibujar(x,y,anchoB,altoB);
	System::Drawing::Rectangle ZonaaUsar(Indice1*anchoFrame,Indice2*altoFrame,anchoFrame,altoFrame);

	C->DrawImage(bmp2,ZonaaDibujar,ZonaaUsar,System::Drawing::GraphicsUnit::Pixel);

	if(Indice1==2)
		Indice1=0;
	else
		Indice1++;
}

///////////////

CVecEnemigos::CVecEnemigos(System::Random ^R,int dx,int dy,int Indice1,int Indice2)
{
	int cant_1=R->Next(1,4);
	int cant_2=R->Next(1,3);
	n=cant_1+cant_2;
	V=new CPersonaje*[n];
	int x=R->Next(200,601)+10,y=0+10;
	int a=100+10,b=200+10;
	x=310;
	for(int i=0;i<n;i++)
		if(i<cant_1)
		{
			V[i]=new CEnemigo1(a,b,dx,dy,50,50,Indice1,Indice2,1);
			a=R->Next(100,601)+10;
			b+=100;
		}
		else
		{
			V[i]=new CEnemigo2(x,y,dx,dy,50,50,Indice1,Indice2,2);
			x=R->Next(100,601)+10;
			y+=100;
		}

	intervalo=0;
	direccion=R->Next(1,5);
}
CVecEnemigos::~CVecEnemigos()
{
	for(int i=0;i<n;i++)
		delete V[i];
	delete []V;
}
void CVecEnemigos::Mover(System::Random ^R,int ancho,int alto,CVecEspacios *P,CBombas *Q)
{
	for(int i=0;i<n;i++)
	{
		if(intervalo==15)
		{
			direccion=R->Next(1,5);
			V[i]->Mover(direccion,ancho,alto,P,Q);
		}
		else
			V[i]->Mover(direccion,ancho,alto,P,Q);
	}
}
void CVecEnemigos::Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2)
{
	for(int i=0;i<n;i++)
		V[i]->Mostrar(C,bmp,bmp2);
	intervalo++;
	if(intervalo>16)
		intervalo=0;
}
bool CVecEnemigos::PierdeContraBomba(CBombas *P)
{
	for(int i=0;i<n;i++)
		if(P->ValidarMuertePorExplosion(V[i]->Get_x(),V[i]->Get_y(),V[i]->Get_anchoB(),V[i]->Get_altoB()))
		{
			delete V[i];
			V[i]=V[n-1];
			n--;
			return true;
		}
}
bool CVecEnemigos::ValidarMataBomber(int x,int y,int an,int al)
{
	for(int i=0;i<n;i++)
	{
		if(x+an>V[i]->Get_x() && x<V[i]->Get_x()+V[i]->Get_anchoB() &&
			y+al>V[i]->Get_y() && y<V[i]->Get_y()+V[i]->Get_altoB())
			return true;
	}
	return false;
}
int CVecEnemigos::Get_n()
{
	return n;
}