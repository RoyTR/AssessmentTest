#include "stdafx.h"

CBomba::CBomba(int x,int y,int diametroBomb,int alcance)
{
	this->x=x;
	this->y=y;
	this->diametroBomb=diametroBomb;
	intervalo_explosion=0;
	Indice=0;
	Indice_explosion=0;
	this->alcance=alcance;
}
CBomba::~CBomba()
{
}
void CBomba::Mostrar(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2)
{
	int anchoFrame=bmp->Width/45;
	int altoFrame=bmp->Height;

	System::Drawing::Rectangle ZonaaDibujar(x,y,diametroBomb,diametroBomb);
	System::Drawing::Rectangle ZonaaUsar(Indice*anchoFrame,0,anchoFrame,altoFrame);

	C->DrawImage(bmp,ZonaaDibujar,ZonaaUsar,System::Drawing::GraphicsUnit::Pixel);

	if(Indice==44)
		Indice=0;
	else
		Indice++;

	// Mostrar la Explosion
	intervalo_explosion++;
	if(intervalo_explosion>=38)
	{
		int anchoFrameB=bmp2->Width/8;
		int altoFrame=bmp2->Height;

		int tama�o_fuego=diametroBomb;
		for(int i=0;i<alcance;i++)
		{
			System::Drawing::Rectangle Q(x-tama�o_fuego,y,diametroBomb,diametroBomb);
			System::Drawing::Rectangle W(Indice_explosion*anchoFrameB,0,anchoFrameB,altoFrame);
			C->DrawImage(bmp2,Q,W,System::Drawing::GraphicsUnit::Pixel);

			System::Drawing::Rectangle E(x+tama�o_fuego,y,diametroBomb,diametroBomb);
			System::Drawing::Rectangle R(Indice_explosion*anchoFrameB,0,anchoFrameB,altoFrame);
			C->DrawImage(bmp2,E,R,System::Drawing::GraphicsUnit::Pixel);

			System::Drawing::Rectangle T(x,y-tama�o_fuego,diametroBomb,diametroBomb);
			System::Drawing::Rectangle Y(Indice_explosion*anchoFrameB,0,anchoFrameB,altoFrame);
			C->DrawImage(bmp2,T,Y,System::Drawing::GraphicsUnit::Pixel);

			System::Drawing::Rectangle U(x,y+tama�o_fuego,diametroBomb,diametroBomb);
			System::Drawing::Rectangle I(Indice_explosion*anchoFrameB,0,anchoFrameB,altoFrame);
			C->DrawImage(bmp2,U,I,System::Drawing::GraphicsUnit::Pixel);

			tama�o_fuego+=diametroBomb;
		}

		if(Indice_explosion==6)
		{
			Indice_explosion=0;
			intervalo_explosion=0;
		}
		else
			Indice_explosion++;
	}
}
int CBomba::Get_intervalo_explosion()
{
	return intervalo_explosion;
}
int CBomba::Get_x()
{
	return x;
}
int CBomba::Get_y()
{
	return y;
}
int CBomba::Get_diametroBomb()
{
	return diametroBomb;
}
////////////////////////

CBombas::CBombas()
{
	n=1;
	aux=0;
	alcance=1;
	V=NULL;
	h=alcance*50;
}
CBombas::~CBombas()
{
	for(int i=0;i<aux;i++)
		delete V[i];
	delete []V;
}
void CBombas::Poner1Bomba(int x,int y)
{
	if(aux==n)
		return;
	CBomba **P=new CBomba*[aux+1];
	if(P==NULL)
		return;
	for(int i=0;i<aux;i++)
		P[i]=V[i];
	P[aux]=new CBomba(x,y,50,alcance);
	if(V!=NULL)
		delete []V;
	aux++;
	V=P;
}
void CBombas::Borrar1Bomba()
{
	int i=0;
	while(i<aux)
	{
		if(V[i]->Get_intervalo_explosion()>=42)
		{
			delete V[i];
			V[i]=V[aux-1];
			aux--;
		}
		else
			i++;
	}
}
void CBombas::MostrarBombas(System::Drawing::Graphics ^C,System::Drawing::Bitmap ^bmp,System::Drawing::Bitmap ^bmp2)
{
	for(int i=0;i<aux;i++)
		V[i]->Mostrar(C,bmp,bmp2);
}
bool CBombas::ValidarMuertePorExplosion(int x,int y,int anchoB,int altoB)
{
	for(int i=0;i<aux;i++)
	{
		if(V[i]->Get_intervalo_explosion()>=38)
		{
			if(x+anchoB>V[i]->Get_x()-h && x<V[i]->Get_x()+V[i]->Get_diametroBomb()+h &&
				y+altoB>V[i]->Get_y() && y<V[i]->Get_y()+V[i]->Get_diametroBomb())
				return true;
			if(x+anchoB>V[i]->Get_x() && x<V[i]->Get_x()+V[i]->Get_diametroBomb() &&
				y+altoB>V[i]->Get_y()-h && y<V[i]->Get_y()+V[i]->Get_diametroBomb()+h)
				return true;
		}
	}
	return false;
}
bool CBombas::SobreBomba(int posx,int posy,int posx2,int posy2,int an,int al)
{
	bool validado=true;
	bool validado2=true;
	for(int i=0;i<aux;i++)
	{
		if(V[i]->Get_intervalo_explosion()<=37)
		{
		if(posx>=V[i]->Get_x() && V[i]->Get_x()+V[i]->Get_diametroBomb()>=posx+an &&
			posy>=V[i]->Get_y() && V[i]->Get_y()+V[i]->Get_diametroBomb()>=posy+al)
			validado=false;
		if(posx2>=V[i]->Get_x() && V[i]->Get_x()+V[i]->Get_diametroBomb()>=posx2 &&
			posy2>=V[i]->Get_y() && V[i]->Get_y()+V[i]->Get_diametroBomb()>=posy2)
			validado2=false;
		}
	}

	if(validado==false && validado2==false)
		return false;
	else
		return true;
}
int CBombas::Get_n()
{
	return n;
}
void CBombas::Set_n(int n)
{
	this->n=n;
}
int CBombas::Get_ALCANCE()
{
	return alcance;
}
void CBombas::Set_ALCANCE(int alcance)
{
	this->alcance=alcance;
}